HYPEPAD FINAL UI PACKAGE

Contents:
- index.html: polished homepage with full nav, mobile hamburger, header/footer, links to presale and launch.
- launch.html: unified Presale/IDO page with tabs and content, now wrapped with consistent header/footer.
- hype_presale.html: standalone presale landing page.
- presale_ui.html: interactive presale dashboard (vesting calculator, claim stub), integrated.
- assets/hypepad-banner-integrated.jpg: brand banner.
- logo-192.png, favicon.ico: icons.

Next: wire real contract logic into presale_ui.html and launch flows. Replace placeholder addresses, adapt as needed.
