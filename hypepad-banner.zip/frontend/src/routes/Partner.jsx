export default function Partner() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>Partner Page</h2>
      <p>Placeholder content for Partner.</p>
    </div>
  );
}
