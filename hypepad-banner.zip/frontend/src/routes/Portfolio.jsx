import React from 'react';

export default function Portfolio() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>Portfolio Page</h2>
      <p>Placeholder content for Portfolio.</p>
    </div>
  );
}
