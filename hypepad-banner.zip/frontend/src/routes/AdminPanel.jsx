import React from 'react';

export default function AdminPanel() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>AdminPanel Page</h2>
      <p>Placeholder content for AdminPanel.</p>
    </div>
  );
}
