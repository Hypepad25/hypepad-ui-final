export default function Airdrop() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>Airdrop Page</h2>
      <p>Placeholder content for Airdrop.</p>
    </div>
  );
}
