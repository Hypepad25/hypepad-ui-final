Patch: Adds missing SEO.jsx component required for build.

Place this file at frontend/src/components/SEO.jsx exactly. Then commit and push:

git add frontend/src/components/SEO.jsx
git commit -m "fix: add missing SEO.jsx component"
git push

Then redeploy on Vercel (clear cache).
