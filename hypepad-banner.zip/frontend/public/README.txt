HYPEPAD Brand Assets Bundle

Generated from provided logo image.
Includes:
- logo-512.png, logo-192.png, logo-64.png: PNG variants for header, touch icons, etc.
- favicon.ico: multi-size favicon (16x16,32x32,48x48,64x64) for browser tabs.
- hypepad-banner.jpg / .png: hero banner with gradient background, logo, and subtitle.

Replace existing placeholders with these. For full branding you can swap in your second photo by editing the banner image: if you upload it I can composite it with the logo/text.

